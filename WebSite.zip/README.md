# FootBallWebSite
1、index.html是主页面
2、导航按钮会将其他页面加载到index.html的<div class="middleDiv" id="middleDivDes"> 
3、其他页面样式参照welcomepage.html/welcomepage.css编写
4、middleDivDes固定长度1200px高770px
